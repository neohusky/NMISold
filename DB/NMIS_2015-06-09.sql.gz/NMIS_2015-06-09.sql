# ************************************************************
# Sequel Pro SQL dump
# Version 4135
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 10.7.145.68 (MySQL 5.5.36)
# Database: NMIS
# Generation Time: 2015-06-09 07:09:03 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table settings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `DWL_ServerAET` text NOT NULL,
  `DWL_ServerIP` text NOT NULL,
  `DWL_ServerPort` int(11) NOT NULL,
  `DWL_OwnAET` text NOT NULL,
  `DWL_OwnIP` text NOT NULL,
  `DWL_SearchModality` text NOT NULL,
  `DWL_RefreshTime` int(11) NOT NULL COMMENT 'Auto Refresh Time in seconds',
  `DWL_Trigger` tinyint(1) NOT NULL COMMENT 'Used to trigger mirth to manually perform worklst query',
  `DWL_LastRun` text NOT NULL COMMENT 'When the last DWL query was performed by mirth',
  `App_TimeOut` int(11) NOT NULL,
  `App_HotlabConnectServer` varchar(12) NOT NULL DEFAULT '',
  `App_HotlabConnectPort` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;

INSERT INTO `settings` (`id`, `DWL_ServerAET`, `DWL_ServerIP`, `DWL_ServerPort`, `DWL_OwnAET`, `DWL_OwnIP`, `DWL_SearchModality`, `DWL_RefreshTime`, `DWL_Trigger`, `DWL_LastRun`, `App_TimeOut`, `App_HotlabConnectServer`, `App_HotlabConnectPort`)
VALUES
	(1,'IWMCHW_DWL','192.168.220.21',1024,'HOTLAB','localhost','NM',300,0,'2015-06-09 17:08:57',300,'10.7.145.98',8080);

/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
